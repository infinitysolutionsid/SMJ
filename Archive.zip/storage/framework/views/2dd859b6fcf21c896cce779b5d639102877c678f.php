<?php $__env->startSection('card','Baca pesan'); ?>
<?php $__env->startSection('berkaspesan'); ?>
<div class="col-md-9">
    <div class="card card-primary card-outline">
        <div class="card-header">
            <h3 class="card-title">Read Mail</h3>

            <div class="card-tools">
                <a href="#" class="btn btn-tool" data-toggle="tooltip" title="Previous"><i
                        class="fas fa-chevron-left"></i></a>
                <a href="#" class="btn btn-tool" data-toggle="tooltip" title="Next"><i
                        class="fas fa-chevron-right"></i></a>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body p-0">
            <div class="mailbox-read-info">
                <h5><?php echo e($pesanmasuk->subject); ?></h5>
                <h6>From: <?php echo e($pesanmasuk->email); ?><br>
                    No HP: <?php echo e($pesanmasuk->nohp); ?><br>
                    Nama: <?php echo e($pesanmasuk->nama); ?>

                    <span class="mailbox-read-time float-right"><?php echo e($pesanmasuk->created_at); ?></span></h6>
            </div>

            <!-- /.mailbox-controls -->
            <div class="mailbox-read-message">
                <p><?php if($pesanmasuk->messages==NULL): ?>Tidak ada catatan pesan dilampirkan.
                    <?php else: ?> <?php echo e($pesanmasuk->messages); ?> <?php endif; ?></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/SMJ/resources/views/dashboard/folderpesan/read.blade.php ENDPATH**/ ?>