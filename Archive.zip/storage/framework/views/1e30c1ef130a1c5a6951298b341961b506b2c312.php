<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('desc'); ?>">

    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="author" content="Bintang j Tobing" />
    <link rel="icon" type="image/png" href="<?php echo asset('storage/img/icon.png'); ?>">
    <title>CV. Sumber Mitra Sejati <?php echo $__env->yieldContent('title'); ?></title>

    <link href="<?php echo asset('css/plugins.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('css/style.css'); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo asset('fontawesome/css/all.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('fontawesome/css/fontawesome.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('dashboard_admin/dist/css/customstyle.css'); ?>">

    <link href="//fonts.googleapis.com/css?family=Open+Sans:400,300,800,700,600%7CRaleway:100,300,600,700,800"
        rel="stylesheet" type="text/css" />
</head>

<body>

    <div class="body-inner">
        <div id="topbar" class="d-none d-xl-block d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <ul class="top-menu">
                            <li><a href="/tel:085370359971">Phone: +62 853 7035 9971</a></li>
                            <li><a href="/tel:085277645378">Phone: +62 852 7764 5378</a></li>
                            <li><a href="/mailto:info@sumberparts.com">Email: info@sumberparts.com</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4 d-none d-sm-block">
                        <div class="social-icons social-icons-colored-hover">
                            <ul>
                                <li class="social-facebook"><a href="https://facebook.com/"><i
                                            class="fab fa-facebook-f"></i></a></li>
                                <li class="social-instagram"><a href="https://instagram.com/"><i
                                            class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <header id="header">
            <div class="header-inner">
                <div class="container">

                    <a href="/"><img src="<?php echo asset('storage/logo.png'); ?>" class="imglogosmj" alt="logo smj"></a>
                    <div id="mainMenu-trigger"> <a class="lines-button x"><span class="lines"></span></a> </div>

                    <div id="mainMenu">
                        <div class="container">
                            <nav>
                                <ul>
                                    <li><a href="/">Beranda</a></li>
                                    <li class="dropdown"><a href="#">Produk kami</a>
                                        <ul class="dropdown-menu">
                                            <li><a href="/hydraulic-dump-truck">Hydraulic Dump Truck</a>
                                            </li>
                                            <li><a href="/sparepart-truck">Sparepart Truck</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="/about">Tentang kami</a></li>
                                    <li><a href="/contact">Hubungi kami</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                </div>
            </div>
        </header>
        <?php echo $__env->yieldContent('content'); ?>

        <footer id="footer">
            <div class="footer-content">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="widget">
                                <div class="widget-title">Sumber Diesel</div>
                                <p class="mb-5">Built with love by <a href="https://infinitysolutions.co.id">Infinity
                                        Solutions</a>
                                    <br> All rights reserved. Copyright © 2019. Infinity Solutions.</p>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <div class="widget">
                                <div class="widget-title">Kantor Kami</div>
                                <h5>Medan</h5>
                                <p>Jl. Rahmadsyah No. 33 C<br>
                                    Kotamatsum III. Kec.Medan<br>
                                    Kota Medan, Sumatera Utara, 20212<br>
                                    <i class="fas fa-phone"></i> +62 853 7035 9971</p>
                            </div>
                            <div class="widget">
                                <h5>Jakarta</h5>
                                <p>Green Sedayu Bizpark<br>
                                    Jl. Daan Mogot Km. 18 Blok DM1/100<br>
                                    Kalideres, Jakarta Barat 11840<br>
                                    <i class="fas fa-phone"></i> +62 852 7764 5378</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-content">
                <div class="container">
                    <div class="copyright-text text-center">&copy; 2019 SUMBER DIESEL
                        All Rights Reserved.<a href="//infinitysolutions.co.id" target="_blank"> Infinity Solutions</a>
                    </div>
                </div>
            </div>
        </footer>

    </div>

    <a id="scrollTop"><i class="icon-chevron-up"></i><i class="icon-chevron-up"></i></a>

    <script src="<?php echo asset('js/jquery.js'); ?>"></script>
    <script src="<?php echo asset('js/plugins.js'); ?>"></script>

    <script src="<?php echo asset('js/functions.js'); ?>"></script>

    <script type='text/javascript'
        src='https://maps.googleapis.com/maps/api/js?key=AIzaSyAZIus-_huNW25Jl7RPmHgoGZjD5udgBMI'></script>
    <script type="text/javascript" src="<?php echo asset('js/gmap3.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo asset('js/map-styles.js'); ?>"></script>
    <script src="<?php echo asset('fontawesome/js/all.min.js'); ?>"></script>
    <script src="<?php echo asset('fontawesome/js/conflict-detection.min.js'); ?>"></script>
    <script src="<?php echo asset('fontawesome/js/fontawesome.js'); ?>"></script>
</body>

</html>
<?php /**PATH /Users/bintangtobing/Documents/GitHub/SMJ/resources/views/homepage/extends.blade.php ENDPATH**/ ?>