<?php $__env->startSection('title','Pesan'); ?>
<?php $__env->startSection('aktifmessages','active'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-3">
        <a href="#" class="btn btn-primary btn-block mb-3"><?php echo $__env->yieldContent('card'); ?></a>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Folders</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <ul class="nav nav-pills flex-column">
                    <li class="nav-item active">
                        <a href="/messages" class="nav-link">
                            <i class="fas fa-inbox"></i> Inbox

                            <span class="badge bg-primary float-right"></span>
                        </a>
                    </li>
                    
                    </a>
                    </li>
                    <li class="nav-item">
                        <a href="/messages/archive/trash" class="nav-link">
                            <i class="far fa-trash-alt"></i> Trash
                        </a>
                    </li>
                </ul>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
    <!-- /.col -->
    <?php echo $__env->yieldContent('berkaspesan'); ?>
    <!-- /.col -->
</div>
<!-- /.row -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bintangtobing/Documents/GitHub/SMJ/resources/views/dashboard/messages.blade.php ENDPATH**/ ?>